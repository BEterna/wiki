Fiscalization is fiscal law designed to avoid retailer fraud in Slovenia and Croatia. Fiscal law about cash registers has been introduced in countries to control the grey economy by enforcing all mandatory transaction reporting to the authorities. According to fiscal law, an appropriate fiscal receipt has to be printed and given to the customer.

Feature allows the generation of number sequence on sales documents (Sales Order, Free text invoice, Project Invoice, Prepayment invoice, FTI corrections, Credit notes, Collection letters, Interest notes  and Advance invoices) according to the Fiscal law. Fiscal number can be seen in field “Invoice” on Customer transaction. After posting, transaction is displayed in Fiscalization documents.

Feature is part of the LOC_FISCALIZATION extended localization package.

[Detailed documentation](http://axweb/D365O%20Localization%20Documents/D365%20ext%20LOC_Fiscalization.docx?Web=1)